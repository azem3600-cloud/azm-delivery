-- =====================================================================
--  عزم ماركت — نظام توزيع الطلبات على الفروع وتطبيق المناديب
--  Supabase / PostgreSQL schema  (آمن لإعادة التشغيل: idempotent)
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1) الجداول
-- ---------------------------------------------------------------------

create table if not exists public.branches (
  id            serial primary key,
  name          text not null unique,
  city          text not null,
  lat           double precision not null,
  lon           double precision not null,
  phone         text,
  address       text,
  max_radius_km numeric(6,2) default 25,       -- أقصى مسافة يخدمها الفرع (للتنبيه فقط)
  is_active     boolean not null default true,
  created_at    timestamptz not null default now()
);

create table if not exists public.profiles (
  id               uuid primary key,              -- = auth.users.id
  username         text not null unique,
  full_name        text not null,
  phone            text,
  role             text not null check (role in ('admin','cashier','driver')),
  branch_id        int references public.branches(id) on delete set null,
  is_active        boolean not null default true,
  is_online        boolean not null default false, -- المندوب متصل/على رأس العمل
  last_lat         double precision,
  last_lon         double precision,
  last_accuracy    double precision,
  last_speed       double precision,
  last_battery     int,
  last_location_at timestamptz,
  last_seen_at     timestamptz,
  vehicle          text,
  created_at       timestamptz not null default now()
);
create index if not exists profiles_branch_role_idx on public.profiles(branch_id, role);

create table if not exists public.orders (
  id                bigserial primary key,
  source            text not null default 'zid' check (source in ('zid','manual')),
  zid_order_id      bigint unique,
  invoice_number    text,
  customer_name     text,
  customer_phone    text,
  customer_email    text,
  address_text      text,
  district          text,
  city              text,
  short_address     text,
  lat               double precision,
  lon               double precision,
  items             jsonb not null default '[]'::jsonb,   -- [{name, sku, quantity, price, total, image}]
  items_count       int not null default 0,
  subtotal          numeric(12,2),
  shipping_fee      numeric(12,2),
  total             numeric(12,2) not null default 0,
  currency          text not null default 'SAR',
  payment_method    text,
  payment_status    text,
  is_cod            boolean not null default false,       -- الدفع عند الاستلام
  cod_amount        numeric(12,2) not null default 0,     -- المبلغ المطلوب تحصيله
  cod_collected     boolean not null default false,
  shipping_method   text,
  customer_note     text,
  internal_note     text,
  zid_status        text,
  status            text not null default 'new'
                    check (status in ('new','preparing','ready','assigned','out_for_delivery','delivered','cancelled')),
  branch_id         int references public.branches(id) on delete set null,
  routing_method    text,              -- nearest | manual | city_fallback | none
  distance_km       numeric(8,2),
  routing           jsonb,             -- المسافات لكل الفروع
  driver_id         uuid references public.profiles(id) on delete set null,
  order_created_at  timestamptz not null default now(),   -- وقت الطلب في زد
  received_at       timestamptz not null default now(),   -- وقت وصوله للنظام
  preparing_at      timestamptz,
  ready_at          timestamptz,
  assigned_at       timestamptz,
  picked_up_at      timestamptz,
  delivered_at      timestamptz,
  cancelled_at      timestamptz,
  cancel_reason     text,
  delivery_lat      double precision,  -- موقع المندوب عند التسليم
  delivery_lon      double precision,
  rating_note       text,
  raw               jsonb,
  updated_at        timestamptz not null default now()
);
create index if not exists orders_status_idx    on public.orders(status);
create index if not exists orders_branch_idx    on public.orders(branch_id, status);
create index if not exists orders_driver_idx    on public.orders(driver_id, status);
create index if not exists orders_created_idx   on public.orders(order_created_at desc);
create index if not exists orders_phone_idx     on public.orders(customer_phone);

create table if not exists public.order_events (
  id          bigserial primary key,
  order_id    bigint not null references public.orders(id) on delete cascade,
  at          timestamptz not null default now(),
  actor_id    uuid,
  actor_name  text,
  type        text not null,          -- created | status | dispatch | reroute | note | zid_sync | zid_push_error
  from_status text,
  to_status   text,
  note        text
);
create index if not exists order_events_order_idx on public.order_events(order_id, at);

create table if not exists public.driver_locations (
  id          bigserial primary key,
  driver_id   uuid not null references public.profiles(id) on delete cascade,
  lat         double precision not null,
  lon         double precision not null,
  accuracy    double precision,
  speed       double precision,
  heading     double precision,
  battery     int,
  order_id    bigint,
  at          timestamptz not null default now()
);
create index if not exists driver_locations_driver_at_idx on public.driver_locations(driver_id, at desc);

-- إعدادات النظام + توكنات زد (لا يقرأها إلا السيرفر)
create table if not exists public.app_settings (
  key        text primary key,
  value      jsonb,
  updated_at timestamptz not null default now()
);

-- طابور تحديث حالة الطلبات في زد
create table if not exists public.zid_outbox (
  id          bigserial primary key,
  order_id    bigint not null references public.orders(id) on delete cascade,
  zid_order_id bigint not null,
  zid_status  text not null,
  attempts    int not null default 0,
  last_error  text,
  done        boolean not null default false,
  created_at  timestamptz not null default now(),
  processed_at timestamptz
);
create index if not exists zid_outbox_pending_idx on public.zid_outbox(done, created_at);

-- سجل الأحداث القادمة من زد (للتشخيص)
create table if not exists public.zid_log (
  id         bigserial primary key,
  at         timestamptz not null default now(),
  kind       text not null,     -- webhook | sync | oauth | push | error
  ok         boolean not null default true,
  message    text,
  payload    jsonb
);
create index if not exists zid_log_at_idx on public.zid_log(at desc);

-- ---------------------------------------------------------------------
-- 2) دوال مساعدة
-- ---------------------------------------------------------------------

create or replace function public.haversine_km(lat1 double precision, lon1 double precision,
                                               lat2 double precision, lon2 double precision)
returns double precision language sql immutable as $$
  select 2 * 6371.0088 * asin(sqrt(
           power(sin(radians(lat2 - lat1) / 2), 2) +
           cos(radians(lat1)) * cos(radians(lat2)) * power(sin(radians(lon2 - lon1) / 2), 2)));
$$;

create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid() and is_active
$$;

create or replace function public.my_branch() returns int
language sql stable security definer set search_path = public as $$
  select branch_id from public.profiles where id = auth.uid() and is_active
$$;

create or replace function public.my_name() returns text
language sql stable security definer set search_path = public as $$
  select coalesce((select full_name from public.profiles where id = auth.uid()), 'النظام')
$$;

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(public.my_role() = 'admin', false)
$$;

-- يحسب أقرب فرع لإحداثيات معينة ويرجع {branch_id, distance_km, all:[...]}
create or replace function public.nearest_branch(p_lat double precision, p_lon double precision)
returns jsonb language sql stable set search_path = public as $$
  with d as (
    select id, name, round(public.haversine_km(p_lat, p_lon, lat, lon)::numeric, 2) as km
    from public.branches where is_active
  )
  select case when p_lat is null or p_lon is null or not exists (select 1 from d) then null
         else jsonb_build_object(
           'branch_id',   (select id from d order by km limit 1),
           'distance_km', (select km from d order by km limit 1),
           'all', (select jsonb_agg(jsonb_build_object('id', id, 'name', name, 'km', km) order by km) from d))
         end
$$;

-- ---------------------------------------------------------------------
-- 3) Triggers
-- ---------------------------------------------------------------------

-- إنشاء ملف المستخدم تلقائياً عند إنشاء حساب في auth.users
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
begin
  insert into public.profiles (id, username, full_name, phone, role, branch_id, vehicle)
  values (new.id,
          coalesce(m->>'username', split_part(new.email, '@', 1)),
          coalesce(m->>'full_name', split_part(new.email, '@', 1)),
          m->>'phone',
          coalesce(m->>'role', 'driver'),
          nullif(m->>'branch_id', '')::int,
          m->>'vehicle')
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- التوجيه التلقائي للطلب لأقرب فرع عند إدخاله
create or replace function public.orders_before_write() returns trigger
language plpgsql security definer set search_path = public as $$
declare r jsonb; v_branch int;
begin
  new.updated_at := now();
  new.items_count := coalesce((select sum(coalesce((x->>'quantity')::numeric, 1))::int
                               from jsonb_array_elements(coalesce(new.items, '[]'::jsonb)) x), 0);
  if new.is_cod and coalesce(new.cod_amount, 0) = 0 then new.cod_amount := new.total; end if;

  if tg_op = 'INSERT' then
    if new.branch_id is null then
      if new.lat is not null and new.lon is not null then
        r := public.nearest_branch(new.lat, new.lon);
        if r is not null then
          new.branch_id := (r->>'branch_id')::int;
          new.distance_km := (r->>'distance_km')::numeric;
          new.routing := r->'all';
          new.routing_method := 'nearest';
        end if;
      end if;
      if new.branch_id is null and new.city is not null then
        -- لا توجد إحداثيات: نوجّه لفرع في نفس المدينة (الأقل ضغطاً)
        select b.id into v_branch from public.branches b
        where b.is_active and (new.city ilike '%' || b.city || '%' or b.city ilike '%' || new.city || '%')
        order by (select count(*) from public.orders o where o.branch_id = b.id
                  and o.status in ('new','preparing','ready','assigned','out_for_delivery')), b.id
        limit 1;
        if v_branch is not null then
          new.branch_id := v_branch; new.routing_method := 'city_fallback';
        end if;
      end if;
      if new.branch_id is null then new.routing_method := 'none'; end if;
    else
      new.routing_method := coalesce(new.routing_method, 'manual');
      if new.lat is not null and new.distance_km is null then
        select round(public.haversine_km(new.lat, new.lon, b.lat, b.lon)::numeric, 2)
          into new.distance_km from public.branches b where b.id = new.branch_id;
      end if;
    end if;
  else
    -- طوابع الوقت لكل حالة
    if new.status is distinct from old.status then
      case new.status
        when 'preparing'        then new.preparing_at := coalesce(new.preparing_at, now());
        when 'ready'            then new.ready_at     := coalesce(new.ready_at, now());
        when 'assigned'         then new.assigned_at  := now();
        when 'out_for_delivery' then new.picked_up_at := now();
        when 'delivered'        then new.delivered_at := now();
        when 'cancelled'        then new.cancelled_at := now();
        else null;
      end case;
    end if;
  end if;
  return new;
end $$;

drop trigger if exists orders_before_write_trg on public.orders;
create trigger orders_before_write_trg before insert or update on public.orders
  for each row execute function public.orders_before_write();

-- سجل الأحداث + طابور تحديث زد
create or replace function public.orders_after_write() returns trigger
language plpgsql security definer set search_path = public as $$
declare z text;
begin
  if tg_op = 'INSERT' then
    insert into public.order_events(order_id, actor_id, actor_name, type, to_status, note)
    values (new.id, auth.uid(), public.my_name(), 'created', new.status,
            case new.routing_method
              when 'nearest' then 'تم التوجيه تلقائياً لأقرب فرع (' || coalesce(new.distance_km::text, '?') || ' كم)'
              when 'city_fallback' then 'لا توجد إحداثيات — تم التوجيه حسب المدينة'
              when 'none' then 'لم يتم تحديد فرع — يحتاج توجيه يدوي'
              else 'تم تحديد الفرع يدوياً' end);
    return new;
  end if;

  if new.status is distinct from old.status then
    insert into public.order_events(order_id, actor_id, actor_name, type, from_status, to_status)
    values (new.id, auth.uid(), public.my_name(), 'status', old.status, new.status);

    -- تحديث الحالة في زد (إلا إذا كان التغيير جاي من زد نفسه)
    if new.source = 'zid' and new.zid_order_id is not null
       and coalesce(current_setting('azm.from_zid', true), '') <> '1' then
      z := case new.status
             when 'preparing' then 'preparing'
             when 'ready' then 'ready'
             when 'out_for_delivery' then 'indelivery'
             when 'delivered' then 'delivered'
             when 'cancelled' then 'cancelled'
             else null end;
      if z is not null and coalesce((select (value)::text from public.app_settings where key = 'zid_push_status'), 'true') <> 'false' then
        insert into public.zid_outbox(order_id, zid_order_id, zid_status) values (new.id, new.zid_order_id, z);
      end if;
    end if;
  end if;

  if new.branch_id is distinct from old.branch_id then
    insert into public.order_events(order_id, actor_id, actor_name, type, note)
    values (new.id, auth.uid(), public.my_name(), 'reroute',
            'تحويل من ' || coalesce((select name from public.branches where id = old.branch_id), '—')
            || ' إلى ' || coalesce((select name from public.branches where id = new.branch_id), '—'));
  end if;

  if new.driver_id is distinct from old.driver_id and new.driver_id is not null then
    insert into public.order_events(order_id, actor_id, actor_name, type, note)
    values (new.id, auth.uid(), public.my_name(), 'dispatch',
            'أُسند للمندوب: ' || coalesce((select full_name from public.profiles where id = new.driver_id), '?'));
  end if;
  return new;
end $$;

drop trigger if exists orders_after_write_trg on public.orders;
create trigger orders_after_write_trg after insert or update on public.orders
  for each row execute function public.orders_after_write();

-- ---------------------------------------------------------------------
-- 4) RPC — العمليات (كل التعديلات تمر من هنا مع التحقق من الصلاحيات)
-- ---------------------------------------------------------------------

-- هل يحق للمستخدم الحالي رؤية/إدارة الطلب؟
create or replace function public.can_manage_order(o public.orders) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_admin()
      or (public.my_role() = 'cashier' and o.branch_id = public.my_branch())
$$;

-- تغيير حالة الطلب
create or replace function public.set_order_status(p_order_id bigint, p_status text, p_note text default null)
returns public.orders language plpgsql security definer set search_path = public as $$
declare o public.orders; v_role text := public.my_role(); ok boolean := false;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'الطلب غير موجود'; end if;
  if v_role is null then raise exception 'غير مصرح'; end if;
  if o.status = p_status then return o; end if;

  if v_role = 'admin' then
    ok := true;
  elsif v_role = 'cashier' then
    ok := o.branch_id = public.my_branch() and (
          (o.status = 'new'       and p_status in ('preparing','cancelled')) or
          (o.status = 'preparing' and p_status in ('ready','new','cancelled')) or
          (o.status = 'ready'     and p_status in ('preparing','cancelled')) or
          (o.status = 'assigned'  and p_status in ('ready','cancelled')));
  elsif v_role = 'driver' then
    ok := o.driver_id = auth.uid() and (
          (o.status = 'assigned'         and p_status in ('out_for_delivery','ready')) or
          (o.status = 'out_for_delivery' and p_status in ('delivered','ready')));
  end if;
  if not ok then raise exception 'لا يمكن تغيير الحالة من % إلى %', o.status, p_status; end if;

  update public.orders set
    status = p_status,
    driver_id = case when p_status in ('new','preparing','ready') then null else driver_id end,
    cancel_reason = case when p_status = 'cancelled' then coalesce(p_note, cancel_reason) else cancel_reason end,
    cod_collected = case when p_status = 'delivered' and is_cod then true else cod_collected end,
    delivery_lat = case when p_status = 'delivered' then (select last_lat from public.profiles where id = auth.uid()) else delivery_lat end,
    delivery_lon = case when p_status = 'delivered' then (select last_lon from public.profiles where id = auth.uid()) else delivery_lon end
  where id = p_order_id returning * into o;

  if p_note is not null and length(trim(p_note)) > 0 then
    insert into public.order_events(order_id, actor_id, actor_name, type, note)
    values (p_order_id, auth.uid(), public.my_name(), 'note', p_note);
  end if;
  return o;
end $$;

-- اختيار المندوب المتاح تلقائياً في الفرع
create or replace function public.pick_driver(p_branch_id int) returns uuid
language sql stable security definer set search_path = public as $$
  select p.id from public.profiles p
  where p.role = 'driver' and p.is_active and p.branch_id = p_branch_id
  order by
    (select count(*) from public.orders o where o.driver_id = p.id and o.status in ('assigned','out_for_delivery')) = 0 desc, -- الفاضي أولاً
    p.is_online desc,                                                                                                        -- المتصل
    (select count(*) from public.orders o where o.driver_id = p.id and o.status in ('assigned','out_for_delivery')),           -- الأقل طلبات
    (select max(o.assigned_at) from public.orders o where o.driver_id = p.id) asc nulls first                                -- الأقدم استلاماً
  limit 1
$$;

-- إرسال الطلب للمندوب (p_driver_id = null → اختيار تلقائي للمندوب الفاضي)
create or replace function public.dispatch_order(p_order_id bigint, p_driver_id uuid default null)
returns public.orders language plpgsql security definer set search_path = public as $$
declare o public.orders; v_driver uuid := p_driver_id; d public.profiles;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'الطلب غير موجود'; end if;
  if not public.can_manage_order(o) then raise exception 'غير مصرح'; end if;
  if o.status in ('delivered','cancelled') then raise exception 'الطلب مغلق'; end if;
  if o.branch_id is null then raise exception 'حدد فرع الطلب أولاً'; end if;

  if v_driver is null then v_driver := public.pick_driver(o.branch_id); end if;
  if v_driver is null then raise exception 'لا يوجد مندوب مسجل لهذا الفرع'; end if;

  select * into d from public.profiles where id = v_driver and role = 'driver' and is_active;
  if not found then raise exception 'المندوب غير صالح'; end if;
  if not public.is_admin() and d.branch_id is distinct from o.branch_id then
    raise exception 'المندوب ليس من نفس الفرع';
  end if;

  update public.orders set driver_id = v_driver, status = 'assigned',
         ready_at = coalesce(ready_at, now()), preparing_at = coalesce(preparing_at, now())
  where id = p_order_id returning * into o;
  return o;
end $$;

-- تحويل الطلب لفرع آخر
create or replace function public.reroute_order(p_order_id bigint, p_branch_id int, p_note text default null)
returns public.orders language plpgsql security definer set search_path = public as $$
declare o public.orders;
begin
  select * into o from public.orders where id = p_order_id for update;
  if not found then raise exception 'الطلب غير موجود'; end if;
  if not public.can_manage_order(o) then raise exception 'غير مصرح'; end if;
  if o.status in ('out_for_delivery','delivered') then raise exception 'لا يمكن تحويل طلب خرج للتوصيل'; end if;
  update public.orders set branch_id = p_branch_id, routing_method = 'manual', driver_id = null,
         status = case when status = 'assigned' then 'ready' else status end,
         distance_km = case when lat is null then null else
           (select round(public.haversine_km(lat, lon, b.lat, b.lon)::numeric, 2) from public.branches b where b.id = p_branch_id) end
  where id = p_order_id returning * into o;
  if p_note is not null then
    insert into public.order_events(order_id, actor_id, actor_name, type, note)
    values (p_order_id, auth.uid(), public.my_name(), 'note', p_note);
  end if;
  return o;
end $$;

-- إضافة ملاحظة
create or replace function public.add_order_note(p_order_id bigint, p_note text)
returns void language plpgsql security definer set search_path = public as $$
declare o public.orders;
begin
  select * into o from public.orders where id = p_order_id;
  if not (public.can_manage_order(o) or o.driver_id = auth.uid()) then raise exception 'غير مصرح'; end if;
  insert into public.order_events(order_id, actor_id, actor_name, type, note)
  values (p_order_id, auth.uid(), public.my_name(), 'note', p_note);
end $$;

-- إنشاء طلب يدوي (هاتف/واتساب) — يتوجّه تلقائياً لأقرب فرع
create or replace function public.create_manual_order(p jsonb)
returns public.orders language plpgsql security definer set search_path = public as $$
declare o public.orders; v_role text := public.my_role();
begin
  if v_role not in ('admin','cashier') then raise exception 'غير مصرح'; end if;
  insert into public.orders(source, customer_name, customer_phone, address_text, district, city,
                            lat, lon, items, total, is_cod, payment_method, payment_status,
                            customer_note, branch_id, invoice_number)
  values ('manual', p->>'customer_name', p->>'customer_phone', p->>'address_text', p->>'district', p->>'city',
          nullif(p->>'lat','')::double precision, nullif(p->>'lon','')::double precision,
          coalesce(p->'items', '[]'::jsonb), coalesce(nullif(p->>'total','')::numeric, 0),
          coalesce((p->>'is_cod')::boolean, true),
          case when coalesce((p->>'is_cod')::boolean, true) then 'الدفع عند الاستلام' else 'مدفوع' end,
          case when coalesce((p->>'is_cod')::boolean, true) then 'pending' else 'paid' end,
          p->>'customer_note',
          case when v_role = 'cashier' and nullif(p->>'branch_id','') is null then public.my_branch()
               else nullif(p->>'branch_id','')::int end,
          'M-' || to_char(now(), 'YYMMDDHH24MISS'))
  returning * into o;
  return o;
end $$;

-- المندوب: تحديث الموقع (يُستدعى من التطبيق كل ~15 ثانية)
create or replace function public.driver_ping(p_lat double precision, p_lon double precision,
                                              p_accuracy double precision default null,
                                              p_speed double precision default null,
                                              p_heading double precision default null,
                                              p_battery int default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_order bigint; v_last timestamptz; v_llat double precision; v_llon double precision;
begin
  if public.my_role() <> 'driver' then raise exception 'غير مصرح'; end if;
  select last_location_at, last_lat, last_lon into v_last, v_llat, v_llon from public.profiles where id = auth.uid();
  update public.profiles set last_lat = p_lat, last_lon = p_lon, last_accuracy = p_accuracy,
         last_speed = p_speed, last_battery = coalesce(p_battery, last_battery),
         last_location_at = now(), last_seen_at = now(), is_online = true
  where id = auth.uid();
  -- نخزن مسار الحركة كل 30 ثانية أو عند التحرك أكثر من 50 متر (لتوفير المساحة)
  if v_last is null or now() - v_last > interval '30 seconds'
     or public.haversine_km(p_lat, p_lon, v_llat, v_llon) > 0.05 then
    select id into v_order from public.orders where driver_id = auth.uid() and status = 'out_for_delivery'
      order by picked_up_at desc limit 1;
    insert into public.driver_locations(driver_id, lat, lon, accuracy, speed, heading, battery, order_id)
    values (auth.uid(), p_lat, p_lon, p_accuracy, p_speed, p_heading, p_battery, v_order);
  end if;
end $$;

-- المندوب: متصل / غير متصل
create or replace function public.driver_set_online(p_online boolean) returns void
language sql security definer set search_path = public as $$
  update public.profiles set is_online = p_online, last_seen_at = now()
  where id = auth.uid() and role = 'driver';
$$;

-- الإدارة: تعديل مستخدم (البيانات العامة — كلمة المرور عبر دالة admin)
create or replace function public.admin_update_profile(p_id uuid, p jsonb) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare r public.profiles;
begin
  if not public.is_admin() then raise exception 'غير مصرح'; end if;
  update public.profiles set
    full_name = coalesce(p->>'full_name', full_name),
    phone     = coalesce(p->>'phone', phone),
    role      = coalesce(p->>'role', role),
    branch_id = case when p ? 'branch_id' then nullif(p->>'branch_id','')::int else branch_id end,
    is_active = coalesce((p->>'is_active')::boolean, is_active),
    vehicle   = coalesce(p->>'vehicle', vehicle)
  where id = p_id returning * into r;
  return r;
end $$;

-- الإدارة: حفظ إعداد (مفاتيح زد غير السرية فقط؛ السر يُحفظ أيضاً هنا لكنه لا يُقرأ من الواجهة)
create or replace function public.admin_set_setting(p_key text, p_value jsonb) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'غير مصرح'; end if;
  if p_key not in ('zid_client_id','zid_client_secret','zid_push_status','zid_import_statuses',
                   'zid_default_location_id','zid_shipping_filter','store_name','dispatch_mode','zid_app_id','web_url') then
    raise exception 'إعداد غير معروف';
  end if;
  insert into public.app_settings(key, value, updated_at) values (p_key, p_value, now())
  on conflict (key) do update set value = excluded.value, updated_at = now();
end $$;

-- الإدارة: قراءة الإعدادات (بدون الأسرار والتوكنات)
create or replace function public.admin_get_settings() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  if not public.is_admin() then raise exception 'غير مصرح'; end if;
  select coalesce(jsonb_object_agg(key, value), '{}'::jsonb) into r
  from public.app_settings where key not in ('zid_client_secret','zid_tokens','webhook_key','cron_key');
  r := r || jsonb_build_object(
    'zid_client_secret_set', exists(select 1 from public.app_settings where key = 'zid_client_secret' and value is not null and value <> '""'::jsonb),
    'zid_connected', exists(select 1 from public.app_settings where key = 'zid_tokens' and value ? 'access_token'),
    'zid_connected_at', (select value->>'obtained_at' from public.app_settings where key = 'zid_tokens'),
    'zid_store', (select value->'store' from public.app_settings where key = 'zid_tokens'),
    'zid_last_sync', (select max(at) from public.zid_log where kind in ('sync','webhook') and ok),
    'zid_outbox_pending', (select count(*) from public.zid_outbox where not done and attempts < 5));
  return r;
end $$;

-- تقرير/إحصائيات لوحة التحكم
create or replace function public.dashboard_stats(p_from timestamptz, p_to timestamptz, p_branch int default null)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v_role text := public.my_role(); v_branch int := p_branch; r jsonb;
begin
  if v_role is null or v_role = 'driver' then raise exception 'غير مصرح'; end if;
  if v_role = 'cashier' then v_branch := public.my_branch(); end if;
  with o as (
    select * from public.orders
    where order_created_at >= p_from and order_created_at < p_to
      and (v_branch is null or branch_id = v_branch)
  )
  select jsonb_build_object(
    'total',      (select count(*) from o),
    'delivered',  (select count(*) from o where status = 'delivered'),
    'cancelled',  (select count(*) from o where status = 'cancelled'),
    'active',     (select count(*) from o where status not in ('delivered','cancelled')),
    'revenue',    (select coalesce(sum(total),0) from o where status = 'delivered'),
    'cod_collected', (select coalesce(sum(cod_amount),0) from o where status = 'delivered' and is_cod),
    'avg_prep_min',     (select round(avg(extract(epoch from (ready_at - received_at))/60)::numeric,1) from o where ready_at is not null),
    'avg_delivery_min', (select round(avg(extract(epoch from (delivered_at - picked_up_at))/60)::numeric,1) from o where delivered_at is not null and picked_up_at is not null),
    'avg_total_min',    (select round(avg(extract(epoch from (delivered_at - received_at))/60)::numeric,1) from o where delivered_at is not null),
    'avg_distance_km',  (select round(avg(distance_km)::numeric,2) from o where distance_km is not null),
    'by_branch', (select coalesce(jsonb_agg(x order by x->>'name'), '[]'::jsonb) from (
        select jsonb_build_object('id', b.id, 'name', b.name,
          'total', count(o.id), 'delivered', count(o.id) filter (where o.status='delivered'),
          'cancelled', count(o.id) filter (where o.status='cancelled'),
          'revenue', coalesce(sum(o.total) filter (where o.status='delivered'),0),
          'avg_total_min', round(avg(extract(epoch from (o.delivered_at - o.received_at))/60)::numeric,1)) x
        from public.branches b left join o on o.branch_id = b.id
        where v_branch is null or b.id = v_branch
        group by b.id, b.name) t),
    'by_driver', (select coalesce(jsonb_agg(x), '[]'::jsonb) from (
        select jsonb_build_object('id', p.id, 'name', p.full_name, 'branch_id', p.branch_id,
          'delivered', count(o.id) filter (where o.status='delivered'),
          'cod', coalesce(sum(o.cod_amount) filter (where o.status='delivered' and o.is_cod),0),
          'avg_delivery_min', round(avg(extract(epoch from (o.delivered_at - o.picked_up_at))/60)::numeric,1)) x
        from public.profiles p left join o on o.driver_id = p.id
        where p.role = 'driver' and (v_branch is null or p.branch_id = v_branch)
        group by p.id, p.full_name, p.branch_id) t),
    'by_hour', (select coalesce(jsonb_agg(jsonb_build_object('h', h, 'n', n) order by h), '[]'::jsonb) from (
        select extract(hour from order_created_at at time zone 'Asia/Riyadh')::int h, count(*) n from o group by 1) t),
    'by_day', (select coalesce(jsonb_agg(jsonb_build_object('d', d, 'n', n, 'rev', rev) order by d), '[]'::jsonb) from (
        select (order_created_at at time zone 'Asia/Riyadh')::date d, count(*) n,
               coalesce(sum(total) filter (where status='delivered'),0) rev from o group by 1) t),
    'top_products', (select coalesce(jsonb_agg(jsonb_build_object('name', name, 'qty', qty) order by qty desc), '[]'::jsonb) from (
        select it->>'name' as name, sum(coalesce((it->>'quantity')::numeric,1)) qty
        from o, jsonb_array_elements(o.items) it where o.status <> 'cancelled'
        group by 1 order by 2 desc limit 10) t)
  ) into r;
  return r;
end $$;

-- ---------------------------------------------------------------------
-- 5) الصلاحيات (Row Level Security)
-- ---------------------------------------------------------------------

alter table public.branches         enable row level security;
alter table public.profiles         enable row level security;
alter table public.orders           enable row level security;
alter table public.order_events     enable row level security;
alter table public.driver_locations enable row level security;
alter table public.app_settings     enable row level security;
alter table public.zid_outbox       enable row level security;
alter table public.zid_log          enable row level security;

drop policy if exists branches_read on public.branches;
create policy branches_read on public.branches for select to authenticated using (true);
drop policy if exists branches_admin on public.branches;
create policy branches_admin on public.branches for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select to authenticated using (
  id = auth.uid() or public.is_admin()
  or (public.my_role() = 'cashier' and branch_id = public.my_branch()));

drop policy if exists orders_read on public.orders;
create policy orders_read on public.orders for select to authenticated using (
  public.is_admin()
  or (public.my_role() = 'cashier' and branch_id = public.my_branch())
  or (public.my_role() = 'driver' and driver_id = auth.uid()));
drop policy if exists orders_admin_write on public.orders;
create policy orders_admin_write on public.orders for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists events_read on public.order_events;
create policy events_read on public.order_events for select to authenticated using (
  exists (select 1 from public.orders o where o.id = order_id));   -- يرث صلاحية الطلب

drop policy if exists locations_read on public.driver_locations;
create policy locations_read on public.driver_locations for select to authenticated using (
  public.is_admin() or driver_id = auth.uid()
  or (public.my_role() = 'cashier' and exists (
        select 1 from public.profiles p where p.id = driver_id and p.branch_id = public.my_branch())));

drop policy if exists zid_log_read on public.zid_log;
create policy zid_log_read on public.zid_log for select to authenticated using (public.is_admin());
-- app_settings و zid_outbox: بدون سياسات = لا وصول إلا للسيرفر (service_role)

revoke all on public.app_settings, public.zid_outbox from anon, authenticated;
revoke insert, update, delete on public.orders, public.order_events, public.driver_locations, public.profiles, public.zid_log from anon, authenticated;
grant update on public.orders to authenticated;   -- مقيّد بسياسة admin فقط
revoke all on public.branches, public.profiles, public.orders, public.order_events, public.driver_locations, public.zid_log from anon;

do $$
declare f text;
begin
  foreach f in array array[
    'set_order_status(bigint,text,text)','dispatch_order(bigint,uuid)','reroute_order(bigint,int,text)',
    'add_order_note(bigint,text)','create_manual_order(jsonb)',
    'driver_ping(double precision,double precision,double precision,double precision,double precision,int)',
    'driver_set_online(boolean)','admin_update_profile(uuid,jsonb)','admin_set_setting(text,jsonb)',
    'admin_get_settings()','dashboard_stats(timestamptz,timestamptz,int)','pick_driver(int)',
    'nearest_branch(double precision,double precision)']
  loop
    execute format('revoke execute on function public.%s from public, anon', f);
    execute format('grant execute on function public.%s to authenticated', f);
  end loop;
end $$;

-- ---------------------------------------------------------------------
-- 6) التحديث اللحظي (Realtime)
-- ---------------------------------------------------------------------
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    begin alter publication supabase_realtime add table public.orders;   exception when duplicate_object then null; end;
    begin alter publication supabase_realtime add table public.profiles; exception when duplicate_object then null; end;
    begin alter publication supabase_realtime add table public.order_events; exception when duplicate_object then null; end;
  end if;
end $$;
alter table public.orders replica identity full;

-- ---------------------------------------------------------------------
-- 7) البيانات الأولية: الفروع الخمسة
-- ---------------------------------------------------------------------
insert into public.branches (name, city, lat, lon) values
  ('بقالة الدمام حي الصفا',       'الدمام', 26.374894763098325, 50.17849699054119),
  ('بقالة الدمام حي الشاطئ',      'الدمام', 26.448549864732943, 50.11783561694023),
  ('بقالة الدمام الندى',          'الدمام', 26.37179816172057,  50.082202768316776),
  ('بقالة الجبيل شارع المدينة',   'الجبيل', 27.002790247574698, 49.635284607987074),
  ('بقالة الجبيل حي الجوهرة',     'الجبيل', 26.97141544746481,  49.64745588814534)
on conflict (name) do update set lat = excluded.lat, lon = excluded.lon, city = excluded.city;

insert into public.app_settings(key, value) values
  ('zid_push_status', 'true'::jsonb),
  ('zid_import_statuses', '["new","preparing","ready"]'::jsonb),
  ('zid_default_location_id', '"1c838879-a249-4eb6-b161-bc1ced967138"'::jsonb),
  ('store_name', '"عزم ماركت"'::jsonb),
  ('webhook_key', to_jsonb(encode(gen_random_bytes(18), 'hex'))),
  ('cron_key', to_jsonb(encode(gen_random_bytes(18), 'hex')))
on conflict (key) do nothing;

-- ---------------------------------------------------------------------
-- 8) دوال السيرفر (تُستدعى من Edge Function بصلاحية service_role فقط)
-- ---------------------------------------------------------------------

-- إدخال/تحديث طلب قادم من زد
create or replace function public.zid_upsert_order(p jsonb, p_force boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id bigint; v_status text; v_zs text := lower(coalesce(p->>'zid_status',''));
        v_import jsonb; v_new boolean := false;
begin
  perform set_config('azm.from_zid', '1', true);
  select id, status into v_id, v_status from public.orders where zid_order_id = (p->>'zid_order_id')::bigint;

  if v_id is null then
    select value into v_import from public.app_settings where key = 'zid_import_statuses';
    if not p_force and v_import is not null and not (v_import ? v_zs) then
      return jsonb_build_object('skipped', true, 'reason', 'status ' || v_zs);
    end if;
    insert into public.orders(source, zid_order_id, invoice_number, customer_name, customer_phone, customer_email,
        address_text, district, city, short_address, lat, lon, items, subtotal, shipping_fee, total, currency,
        payment_method, payment_status, is_cod, shipping_method, customer_note, zid_status, order_created_at, raw)
    values ('zid', (p->>'zid_order_id')::bigint, p->>'invoice_number', p->>'customer_name', p->>'customer_phone',
        p->>'customer_email', p->>'address_text', p->>'district', p->>'city', p->>'short_address',
        nullif(p->>'lat','')::double precision, nullif(p->>'lon','')::double precision,
        coalesce(p->'items','[]'::jsonb), nullif(p->>'subtotal','')::numeric, nullif(p->>'shipping_fee','')::numeric,
        coalesce(nullif(p->>'total','')::numeric, 0), coalesce(p->>'currency','SAR'),
        p->>'payment_method', p->>'payment_status', coalesce((p->>'is_cod')::boolean, false),
        p->>'shipping_method', p->>'customer_note', v_zs,
        coalesce(nullif(p->>'order_created_at','')::timestamptz, now()), p->'raw')
    returning id into v_id;
    v_new := true;
    -- لو الطلب في زد بحالة متقدمة نعكسها
    if v_zs in ('preparing','ready') then
      update public.orders set status = v_zs where id = v_id;
    end if;
  else
    update public.orders set
      zid_status = v_zs,
      payment_status = coalesce(p->>'payment_status', payment_status),
      status = case
        when v_zs = 'cancelled' and status not in ('delivered','cancelled') then 'cancelled'
        when v_zs = 'delivered' and status not in ('delivered','cancelled') then 'delivered'
        else status end,
      cancel_reason = case when v_zs = 'cancelled' and status <> 'cancelled' then 'أُلغي من زد' else cancel_reason end,
      raw = coalesce(p->'raw', raw)
    where id = v_id;
  end if;
  return jsonb_build_object('id', v_id, 'new', v_new);
end $$;

-- تنظيف البيانات القديمة (يُشغل يومياً)
create or replace function public.housekeeping() returns void
language sql security definer set search_path = public as $$
  delete from public.driver_locations where at < now() - interval '90 days';
  delete from public.zid_log where at < now() - interval '30 days';
  delete from public.zid_outbox where done and processed_at < now() - interval '30 days';
  update public.profiles set is_online = false
   where role = 'driver' and is_online and coalesce(last_seen_at, now() - interval '1 day') < now() - interval '30 minutes';
$$;

revoke execute on function public.zid_upsert_order(jsonb, boolean) from public, anon, authenticated;
revoke execute on function public.housekeeping() from public, anon, authenticated;
