// =====================================================================
//  عزم ماركت — إدارة المستخدمين (Supabase Edge Function: admin)
//  actions: bootstrap | create_user | set_password | delete_user
//  ملاحظة: انشر هذه الدالة مع إيقاف "Verify JWT" (نتحقق داخلياً)
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(SB_URL, SB_SERVICE, { auth: { persistSession: false, autoRefreshToken: false } });
const EMAIL_DOMAIN = "azm-market.app";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" } });

const cleanUsername = (u: string) => String(u ?? "").trim().toLowerCase();
const validUsername = (u: string) => /^[a-z0-9._-]{3,32}$/.test(u);

async function currentAdmin(req: Request) {
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const { data } = await db.auth.getUser(token);
  if (!data?.user) return null;
  const { data: p } = await db.from("profiles").select("*").eq("id", data.user.id).maybeSingle();
  return p?.role === "admin" && p?.is_active ? p : null;
}

async function createUser(b: any, role?: string) {
  const username = cleanUsername(b.username);
  if (!validUsername(username)) throw new Error("اسم المستخدم لازم يكون إنجليزي (حروف/أرقام) من 3 إلى 32 حرف");
  if (!b.password || String(b.password).length < 6) throw new Error("كلمة المرور لازم تكون 6 أحرف أو أكثر");
  const r = role ?? b.role;
  if (!["admin", "cashier", "driver"].includes(r)) throw new Error("الدور غير صحيح");
  if (r !== "admin" && !b.branch_id) throw new Error("حدد الفرع");
  const { data: exists } = await db.from("profiles").select("id").eq("username", username).maybeSingle();
  if (exists) throw new Error("اسم المستخدم مستخدم من قبل");
  const { data, error } = await db.auth.admin.createUser({
    email: `${username}@${EMAIL_DOMAIN}`,
    password: String(b.password),
    email_confirm: true,
    user_metadata: {
      username, role: r,
      full_name: String(b.full_name ?? username).trim(),
      phone: b.phone ?? null,
      branch_id: r === "admin" ? null : String(b.branch_id),
      vehicle: b.vehicle ?? null,
    },
  });
  if (error) throw new Error(error.message);
  // ضمان إنشاء الملف (لو التريقر ما اشتغل لأي سبب)
  await db.from("profiles").upsert({
    id: data.user!.id, username, role: r,
    full_name: String(b.full_name ?? username).trim(), phone: b.phone ?? null,
    branch_id: r === "admin" ? null : Number(b.branch_id), vehicle: b.vehicle ?? null,
  }, { onConflict: "id" });
  return data.user!.id;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  try {
    const b = await req.json().catch(() => ({}));
    switch (b.action) {
      case "bootstrap_status": {
        const { count } = await db.from("profiles").select("id", { count: "exact", head: true }).eq("role", "admin");
        return json({ needs_bootstrap: (count ?? 0) === 0 });
      }
      case "bootstrap": {
        // إنشاء أول مدير — يعمل مرة واحدة فقط
        const { count } = await db.from("profiles").select("id", { count: "exact", head: true }).eq("role", "admin");
        if ((count ?? 0) > 0) return json({ error: "تم إنشاء المدير مسبقاً" }, 403);
        const id = await createUser(b, "admin");
        return json({ ok: true, id });
      }
      case "create_user": {
        if (!(await currentAdmin(req))) return json({ error: "غير مصرح" }, 401);
        const id = await createUser(b);
        return json({ ok: true, id });
      }
      case "set_password": {
        if (!(await currentAdmin(req))) return json({ error: "غير مصرح" }, 401);
        if (!b.password || String(b.password).length < 6) throw new Error("كلمة المرور لازم تكون 6 أحرف أو أكثر");
        const { error } = await db.auth.admin.updateUserById(b.user_id, { password: String(b.password) });
        if (error) throw new Error(error.message);
        return json({ ok: true });
      }
      case "delete_user": {
        const admin = await currentAdmin(req);
        if (!admin) return json({ error: "غير مصرح" }, 401);
        if (admin.id === b.user_id) throw new Error("لا يمكنك حذف حسابك");
        const { count } = await db.from("orders").select("id", { count: "exact", head: true }).eq("driver_id", b.user_id);
        if ((count ?? 0) > 0) {
          // عنده طلبات سابقة: نعطّله بدل الحذف للحفاظ على السجل
          await db.from("profiles").update({ is_active: false, is_online: false }).eq("id", b.user_id);
          await db.auth.admin.updateUserById(b.user_id, { ban_duration: "876000h" });
          return json({ ok: true, deactivated: true });
        }
        await db.from("profiles").delete().eq("id", b.user_id);
        const { error } = await db.auth.admin.deleteUser(b.user_id);
        if (error) throw new Error(error.message);
        return json({ ok: true, deleted: true });
      }
      case "set_active": {
        if (!(await currentAdmin(req))) return json({ error: "غير مصرح" }, 401);
        await db.from("profiles").update({ is_active: !!b.active, ...(b.active ? {} : { is_online: false }) }).eq("id", b.user_id);
        await db.auth.admin.updateUserById(b.user_id, { ban_duration: b.active ? "none" : "876000h" });
        return json({ ok: true });
      }
      default:
        return json({ error: "unknown action" }, 400);
    }
  } catch (e) {
    return json({ error: (e as Error).message }, 400);
  }
});
