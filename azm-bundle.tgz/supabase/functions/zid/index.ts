// =====================================================================
//  عزم ماركت — دالة الربط مع زد (Supabase Edge Function: zid)
//  - install  : بدء ربط المتجر (OAuth)
//  - callback : استلام التوكن من زد + تسجيل الـ Webhooks + مزامنة أولية
//  - webhook  : استقبال الطلبات الجديدة وتحديثات الحالة من زد لحظياً
//  - cron     : مزامنة احتياطية كل دقيقة + إرسال الحالات + تجديد التوكن
//  - push     : إرسال تحديثات الحالة لزد فوراً
//  - sync     : مزامنة يدوية من لوحة التحكم (مدير فقط)
//  - status   : فحص حالة الربط (مدير فقط)
//  ملاحظة: انشر هذه الدالة مع إيقاف "Verify JWT"
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(SB_URL, SB_SERVICE, { auth: { persistSession: false } });

const ZID_API = "https://api.zid.sa/v1";
const ZID_OAUTH = "https://oauth.zid.sa";
const FN_URL = `${SB_URL}/functions/v1/zid`;

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-key",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" } });
const html = (msg: string, ok = true, redirect?: string) =>
  new Response(
    `<!doctype html><html dir="rtl" lang="ar"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>عزم ماركت</title><body style="font-family:system-ui,Tahoma;background:#f4f6f8;display:grid;place-items:center;min-height:100vh;margin:0">
<div style="background:#fff;padding:32px;border-radius:16px;max-width:440px;text-align:center;box-shadow:0 4px 24px #0001">
<div style="font-size:48px">${ok ? "✅" : "⚠️"}</div><h2>${msg}</h2>
${redirect ? `<p><a href="${redirect}" style="color:#0f766e">العودة للوحة التحكم</a></p><script>setTimeout(()=>location.href=${JSON.stringify(redirect)},2500)</script>` : ""}
</div></body></html>`,
    { status: ok ? 200 : 400, headers: { "Content-Type": "text/html; charset=utf-8" } },
  );

// ------------------------------------------------------------------ settings
async function getSetting<T = any>(key: string): Promise<T | null> {
  const { data } = await db.from("app_settings").select("value").eq("key", key).maybeSingle();
  return (data?.value ?? null) as T | null;
}
async function setSetting(key: string, value: unknown) {
  await db.from("app_settings").upsert({ key, value, updated_at: new Date().toISOString() });
}
async function log(kind: string, ok: boolean, message: string, payload?: unknown) {
  try { await db.from("zid_log").insert({ kind, ok, message: message?.slice(0, 1000), payload: payload ?? null }); } catch (_) { /* ignore */ }
}

// ------------------------------------------------------------------ zid api
type Tokens = { access_token: string; authorization: string; refresh_token: string; expires_at?: string; obtained_at?: string; store?: unknown };

async function zid(path: string, init: RequestInit = {}, tokens?: Tokens): Promise<any> {
  const t = tokens ?? (await getSetting<Tokens>("zid_tokens"));
  if (!t?.access_token) throw new Error("المتجر غير مربوط بزد");
  const res = await fetch(`${ZID_API}${path}`, {
    ...init,
    headers: {
      "Authorization": `Bearer ${t.authorization}`,
      "X-Manager-Token": t.access_token,
      "Accept": "application/json",
      "Accept-Language": "ar",
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  const text = await res.text();
  let body: any; try { body = JSON.parse(text); } catch { body = text; }
  if (!res.ok) throw new Error(`Zid ${res.status} ${path}: ${typeof body === "string" ? body.slice(0, 300) : JSON.stringify(body).slice(0, 300)}`);
  return body;
}

async function tokenRequest(params: Record<string, string>): Promise<Tokens> {
  const clientId = await getSetting<string>("zid_client_id");
  const clientSecret = await getSetting<string>("zid_client_secret");
  if (!clientId || !clientSecret) throw new Error("أدخل Client ID و Client Secret من إعدادات النظام أولاً");
  const form = new URLSearchParams({ client_id: String(clientId), client_secret: String(clientSecret), ...params });
  const res = await fetch(`${ZID_OAUTH}/oauth/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json" },
    body: form,
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok || !body.access_token) throw new Error(`فشل الحصول على التوكن من زد (${res.status}): ${JSON.stringify(body).slice(0, 300)}`);
  const now = Date.now();
  return {
    access_token: body.access_token,
    authorization: body.authorization,
    refresh_token: body.refresh_token,
    expires_at: new Date(now + (Number(body.expires_in) || 31536000) * 1000).toISOString(),
    obtained_at: new Date(now).toISOString(),
  };
}

async function refreshIfNeeded() {
  const t = await getSetting<Tokens>("zid_tokens");
  if (!t?.refresh_token || !t.obtained_at) return;
  const ageDays = (Date.now() - Date.parse(t.obtained_at)) / 86400000;
  if (ageDays < 300) return; // التوكن المجدِّد صالح سنة — نجدده بعد ~10 أشهر
  try {
    const nt = await tokenRequest({ grant_type: "refresh_token", refresh_token: t.refresh_token, redirect_uri: `${FN_URL}?action=callback` });
    await setSetting("zid_tokens", { ...t, ...nt });
    await log("oauth", true, "تم تجديد توكن زد");
  } catch (e) {
    await log("oauth", false, `فشل تجديد التوكن: ${(e as Error).message}`);
  }
}

// ------------------------------------------------------------------ normalize
const num = (v: unknown) => {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : parseFloat(String(v).replace(/[^\d.\-]/g, ""));
  return Number.isFinite(n) ? n : null;
};
const round2 = (n: number | null) => (n === null ? null : Math.round(n * 100) / 100);

function normPhone(p?: string | null) {
  if (!p) return null;
  let s = String(p).replace(/[^\d+]/g, "");
  if (s.startsWith("00")) s = "+" + s.slice(2);
  if (/^05\d{8}$/.test(s)) s = "+966" + s.slice(1);
  if (/^5\d{8}$/.test(s)) s = "+966" + s;
  if (/^966\d{9}$/.test(s)) s = "+" + s;
  return s;
}

function zidTime(s?: string | null) {
  if (!s) return null;
  if (/[zZ]|[+\-]\d\d:?\d\d$/.test(s)) return new Date(s).toISOString();
  const d = new Date(s.replace(" ", "T") + "+03:00"); // أوقات زد بتوقيت الرياض
  return isNaN(d.getTime()) ? null : d.toISOString();
}

function productImage(p: any): string | null {
  const im = p?.images?.[0] ?? p?.image;
  if (!im) return null;
  if (typeof im === "string") return im;
  return im?.image?.small ?? im?.image?.medium ?? im?.small ?? im?.thumbnail ?? im?.origin ?? im?.url ?? null;
}

function normalizeOrder(o: any) {
  const addr = o?.shipping?.address ?? o?.address ?? {};
  const pm = o?.payment?.method ?? o?.payment_method ?? {};
  const pmCode = String(pm?.code ?? "").toLowerCase();
  const pmName = String(pm?.name ?? "");
  const isCod = pmCode.includes("cod") || /الاستلام|cash/i.test(pmName);
  const items = (o?.products ?? []).map((p: any) => ({
    name: p?.name ?? p?.product?.name ?? "منتج",
    sku: p?.sku ?? null,
    quantity: num(p?.quantity) ?? 1,
    price: round2(num(p?.price)),
    total: round2(num(p?.total) ?? (num(p?.price) ?? 0) * (num(p?.quantity) ?? 1)),
    image: productImage(p),
    options: Array.isArray(p?.options) ? p.options.map((x: any) => `${x?.name ?? ""}: ${x?.value ?? ""}`).filter((s: string) => s.trim() !== ":") : [],
  }));
  const total = num(o?.order_total) ?? num(o?.transaction_amount) ?? items.reduce((a: number, b: any) => a + (b.total ?? 0), 0);
  const addressParts = [addr?.formatted_address, addr?.street, addr?.district, addr?.city?.name]
    .filter((x: any) => x && x !== "N/A" && String(x).length > 1);
  return {
    zid_order_id: o?.id,
    invoice_number: String(o?.invoice_number ?? o?.code ?? o?.id ?? ""),
    customer_name: o?.customer?.name ?? addr?.name ?? null,
    customer_phone: normPhone(o?.customer?.mobile ?? addr?.mobile ?? o?.customer?.phone),
    customer_email: o?.customer?.email ?? null,
    address_text: [...new Set(addressParts)].join("، ") || null,
    district: addr?.district ?? null,
    city: addr?.city?.name ?? (typeof addr?.city === "string" ? addr.city : null),
    short_address: addr?.short_address ?? null,
    lat: num(addr?.lat ?? addr?.latitude),
    lon: num(addr?.lng ?? addr?.lon ?? addr?.longitude),
    items,
    subtotal: round2(num(o?.products_sum_total)),
    shipping_fee: round2(num(o?.shipping?.method?.cost ?? o?.shipping_cost)),
    total: round2(total),
    currency: o?.currency_code ?? "SAR",
    payment_method: pmName || null,
    payment_status: o?.payment_status ?? null,
    is_cod: isCod,
    shipping_method: o?.shipping?.method?.name ?? null,
    customer_note: o?.customer_note ?? o?.notes ?? o?.note ?? null,
    zid_status: String(o?.order_status?.code ?? o?.status ?? "new").toLowerCase(),
    order_created_at: zidTime(o?.created_at),
    raw: o,
  };
}

async function upsertZidOrder(o: any, force = false) {
  const n = normalizeOrder(o);
  if (!n.zid_order_id) throw new Error("طلب بدون رقم");
  // فلتر طرق الشحن (اختياري): مثال ["مندوب المتجر"]
  const filter = await getSetting<string[]>("zid_shipping_filter");
  if (!force && Array.isArray(filter) && filter.length && n.shipping_method && !filter.includes(n.shipping_method)) {
    const { data: ex } = await db.from("orders").select("id").eq("zid_order_id", n.zid_order_id).maybeSingle();
    if (!ex) return { skipped: true, reason: "shipping_method" };
  }
  const { data, error } = await db.rpc("zid_upsert_order", { p: n, p_force: force });
  if (error) throw new Error(error.message);
  return data;
}

async function fetchOrder(id: number | string) {
  const r = await zid(`/managers/store/orders/${id}/view`);
  return r?.order ?? r?.data ?? r;
}

// مزامنة: نجلب آخر الطلبات ونضيف الجديد ونحدّث حالات الموجود
async function syncRecent(pages = 1, perPage = 50) {
  let added = 0, updated = 0, skipped = 0;
  for (let page = 1; page <= pages; page++) {
    const r = await zid(`/managers/store/orders?page=${page}&per_page=${perPage}&order_by=id&sort_by=desc`);
    const list: any[] = r?.orders ?? r?.data ?? [];
    if (!list.length) break;
    const ids = list.map((o) => o.id);
    const { data: existing } = await db.from("orders").select("zid_order_id, zid_status").in("zid_order_id", ids);
    const ex = new Map((existing ?? []).map((e: any) => [Number(e.zid_order_id), e.zid_status]));
    for (const o of list) {
      const st = String(o?.order_status?.code ?? o?.status ?? "").toLowerCase();
      try {
        if (ex.has(Number(o.id))) {
          if (ex.get(Number(o.id)) !== st) { await upsertZidOrder(o); updated++; }
          continue;
        }
        const needsDetail = !o?.products?.length || o?.shipping?.address?.lat === undefined;
        const full = needsDetail ? await fetchOrder(o.id).catch(() => o) : o;
        const res: any = await upsertZidOrder(full);
        if (res?.skipped) skipped++; else added++;
      } catch (e) {
        await log("sync", false, `طلب ${o?.id}: ${(e as Error).message}`);
      }
    }
    if (list.length < perPage) break;
  }
  return { added, updated, skipped };
}

// إرسال تحديثات الحالة لزد
async function pushOutbox() {
  const { data: rows } = await db.from("zid_outbox").select("*").eq("done", false).lt("attempts", 5)
    .order("id").limit(25);
  if (!rows?.length) return { pushed: 0 };
  const locationId = await getSetting<string>("zid_default_location_id");
  let pushed = 0;
  // نرسل آخر حالة فقط لكل طلب، ونقفل السابقة
  const latest = new Map<number, any>();
  for (const r of rows) latest.set(r.zid_order_id, r);
  for (const r of rows) {
    if (latest.get(r.zid_order_id)?.id !== r.id) {
      await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), last_error: "superseded" }).eq("id", r.id);
    }
  }
  for (const r of latest.values()) {
    const body: Record<string, unknown> = { order_status: r.zid_status };
    if (r.zid_status === "ready" && locationId) body.inventory_address_id = locationId;
    try {
      await zid(`/managers/store/orders/${r.zid_order_id}/change-order-status`, { method: "POST", body: JSON.stringify(body) });
      await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), attempts: r.attempts + 1, last_error: null }).eq("id", r.id);
      await db.from("orders").update({ zid_status: r.zid_status }).eq("id", r.order_id);
      pushed++;
    } catch (e) {
      const msg = (e as Error).message;
      await db.from("zid_outbox").update({ attempts: r.attempts + 1, last_error: msg.slice(0, 500) }).eq("id", r.id);
      await db.from("order_events").insert({ order_id: r.order_id, type: "zid_push_error", note: `تعذر تحديث الحالة في زد: ${msg.slice(0, 200)}` });
      await log("push", false, msg, { order: r.zid_order_id, status: r.zid_status });
    }
  }
  return { pushed };
}

async function registerWebhooks() {
  const key = await getSetting<string>("webhook_key");
  const appId = await getSetting<number>("zid_app_id");
  const target = `${FN_URL}?action=webhook&key=${key}`;
  const results: string[] = [];
  let existing: any[] = [];
  try {
    const r = await zid(`/managers/webhooks`);
    existing = r?.data ?? r?.webhooks ?? [];
  } catch (_) { /* ignore */ }
  for (const event of ["order.create", "order.status.update", "order.payment_status.update"]) {
    if (existing.some((w: any) => w?.event === event && String(w?.target_url ?? "").startsWith(FN_URL))) {
      results.push(`${event}: موجود`); continue;
    }
    try {
      const body: Record<string, unknown> = { event, target_url: target, conditions: {} };
      if (appId) body.original_id = appId;
      await zid(`/managers/webhooks`, { method: "POST", body: JSON.stringify(body) });
      results.push(`${event}: تم`);
    } catch (e) {
      results.push(`${event}: ${(e as Error).message.slice(0, 120)}`);
    }
  }
  await log("oauth", true, `تسجيل Webhooks: ${results.join(" | ")}`);
  return results;
}

async function requireAdmin(req: Request, tokenOverride?: string | null) {
  const auth = tokenOverride ?? req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!auth) return false;
  const { data } = await db.auth.getUser(auth);
  if (!data?.user) return false;
  const { data: p } = await db.from("profiles").select("role, is_active").eq("id", data.user.id).maybeSingle();
  return p?.role === "admin" && p?.is_active;
}

async function checkCronKey(req: Request) {
  const key = await getSetting<string>("cron_key");
  return !!key && req.headers.get("x-cron-key") === key;
}

// ------------------------------------------------------------------ handler
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const url = new URL(req.url);
  const action = url.searchParams.get("action") ?? "";
  const webUrl = (await getSetting<string>("web_url")) ?? "";

  try {
    switch (action) {
      // ---------------------------------------------------------- OAuth
      case "install": {
        const clientId = await getSetting<string>("zid_client_id");
        if (!clientId) return html("لم يتم إدخال Client ID في إعدادات النظام", false, webUrl || undefined);
        const state = crypto.randomUUID();
        await setSetting("oauth_state", { state, at: Date.now() });
        const q = new URLSearchParams({
          client_id: String(clientId),
          redirect_uri: `${FN_URL}?action=callback`,
          response_type: "code",
          state,
        });
        return Response.redirect(`${ZID_OAUTH}/oauth/authorize?${q}`, 302);
      }
      case "callback": {
        const code = url.searchParams.get("code");
        const state = url.searchParams.get("state");
        const saved = await getSetting<{ state: string; at: number }>("oauth_state");
        if (!code) return html("لم يصل رمز التفويض من زد", false, webUrl || undefined);
        if (state && saved?.state && state !== saved.state) return html("رمز الحالة غير مطابق — أعد المحاولة", false, webUrl || undefined);
        const t = await tokenRequest({ grant_type: "authorization_code", code, redirect_uri: `${FN_URL}?action=callback` });
        // معلومات المتجر + حماية من ربط متجر آخر
        let store: any = null;
        try {
          const prof = await zid(`/managers/account/profile`, {}, t);
          const s = prof?.user?.store ?? prof?.store ?? null;
          store = s ? { id: s.id, title: s.title ?? s.name, url: s.url } : null;
        } catch (_) { /* ignore */ }
        const lockedStore = await getSetting<any>("zid_store_id");
        if (lockedStore && store?.id && String(lockedStore) !== String(store.id)) {
          await log("oauth", false, "محاولة ربط متجر مختلف", store);
          return html("هذا المتجر غير مصرح له بالربط مع النظام", false, webUrl || undefined);
        }
        if (store?.id && !lockedStore) await setSetting("zid_store_id", store.id);
        await setSetting("zid_tokens", { ...t, store });
        await setSetting("oauth_state", null);
        await log("oauth", true, `تم ربط المتجر ${store?.title ?? ""}`);
        await registerWebhooks();
        try { const r = await syncRecent(2, 50); await log("sync", true, `مزامنة أولية: ${JSON.stringify(r)}`); } catch (e) { await log("sync", false, (e as Error).message); }
        return html("تم ربط متجرك في زد بنجاح 🎉", true, webUrl ? `${webUrl}#settings` : undefined);
      }

      // ---------------------------------------------------------- Webhook
      case "webhook": {
        const key = await getSetting<string>("webhook_key");
        if (!key || url.searchParams.get("key") !== key) return json({ error: "unauthorized" }, 401);
        const body = await req.json().catch(() => ({}));
        const o = body?.order ?? body?.data ?? body;
        const id = o?.id ?? o?.order_id;
        if (!id) { await log("webhook", false, "payload بدون رقم طلب", body); return json({ ok: true }); }
        let full = o;
        try { full = await fetchOrder(id); } catch (_) { /* نستخدم بيانات الـ payload */ }
        const r = await upsertZidOrder(full);
        await log("webhook", true, `طلب ${id} (${full?.order_status?.code ?? ""})`, { result: r });
        return json({ ok: true, result: r });
      }

      // ---------------------------------------------------------- Cron
      case "cron": {
        if (!(await checkCronKey(req))) return json({ error: "unauthorized" }, 401);
        const push = await pushOutbox();
        let sync: unknown = null;
        try { sync = await syncRecent(1, 30); } catch (e) { await log("sync", false, (e as Error).message); }
        // فحص التوكن مرة في الساعة تقريباً
        if (new Date().getMinutes() === 7) await refreshIfNeeded();
        if (sync && ((sync as any).added || (sync as any).updated)) await log("sync", true, `مزامنة دورية: ${JSON.stringify(sync)}`);
        return json({ ok: true, push, sync });
      }
      case "push": {
        if (!(await checkCronKey(req))) return json({ error: "unauthorized" }, 401);
        return json({ ok: true, ...(await pushOutbox()) });
      }

      // ---------------------------------------------------------- Admin
      case "sync": {
        if (!(await requireAdmin(req))) return json({ error: "غير مصرح" }, 401);
        const pages = Math.min(Number(url.searchParams.get("pages") ?? 2), 10);
        const r = await syncRecent(pages, 50);
        await log("sync", true, `مزامنة يدوية: ${JSON.stringify(r)}`);
        return json({ ok: true, ...r });
      }
      case "import": {
        if (!(await requireAdmin(req))) return json({ error: "غير مصرح" }, 401);
        const id = url.searchParams.get("id");
        if (!id) return json({ error: "رقم الطلب مطلوب" }, 400);
        const r = await upsertZidOrder(await fetchOrder(id), true);
        return json({ ok: true, result: r });
      }
      case "webhooks": {
        if (!(await requireAdmin(req))) return json({ error: "غير مصرح" }, 401);
        return json({ ok: true, results: await registerWebhooks() });
      }
      case "status": {
        if (!(await requireAdmin(req))) return json({ error: "غير مصرح" }, 401);
        const t = await getSetting<Tokens>("zid_tokens");
        if (!t?.access_token) return json({ connected: false });
        try {
          const r = await zid(`/managers/store/orders?page=1&per_page=1`);
          return json({ connected: true, ok: true, store: t.store, total_orders: r?.total_order_count ?? null, expires_at: t.expires_at });
        } catch (e) {
          return json({ connected: true, ok: false, error: (e as Error).message, store: t.store });
        }
      }
      case "disconnect": {
        if (!(await requireAdmin(req))) return json({ error: "غير مصرح" }, 401);
        await setSetting("zid_tokens", null);
        await log("oauth", true, "تم فصل الربط مع زد");
        return json({ ok: true });
      }
      default:
        return json({ ok: true, service: "azm-zid", actions: ["install", "callback", "webhook", "cron", "push", "sync", "import", "status"] });
    }
  } catch (e) {
    const msg = (e as Error).message;
    await log(action || "error", false, msg);
    if (action === "callback" || action === "install") return html(msg, false, webUrl || undefined);
    return json({ ok: false, error: msg }, 500);
  }
});
