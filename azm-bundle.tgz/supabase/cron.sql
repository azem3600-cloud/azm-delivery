-- =====================================================================
--  المهام المجدولة (تُشغل مرة واحدة بعد schema.sql)
--  استبدل hoxhnlxubvqpgovgpkfm بمعرّف مشروع Supabase
-- =====================================================================
create extension if not exists pg_cron;
create extension if not exists pg_net;

insert into public.app_settings(key, value) values ('functions_url', '"https://hoxhnlxubvqpgovgpkfm.supabase.co/functions/v1"')
on conflict (key) do update set value = excluded.value;

-- استدعاء دالة زد (مزامنة + إرسال الحالات + تجديد التوكن)
create or replace function public.call_zid_function(p_action text) returns void
language plpgsql security definer set search_path = public as $$
declare v_url text; v_key text;
begin
  select value #>> '{}' into v_url from public.app_settings where key = 'functions_url';
  select value #>> '{}' into v_key from public.app_settings where key = 'cron_key';
  perform net.http_post(
    url := v_url || '/zid?action=' || p_action,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-cron-key', v_key),
    body := '{}'::jsonb,
    timeout_milliseconds := 20000);
end $$;
revoke execute on function public.call_zid_function(text) from public, anon, authenticated;

-- إرسال تحديث الحالة لزد فوراً عند تغيّر حالة الطلب
create or replace function public.zid_outbox_notify() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from public.app_settings where key = 'zid_tokens' and value ? 'access_token') then
    perform public.call_zid_function('push');
  end if;
  return null;
end $$;
drop trigger if exists zid_outbox_notify_trg on public.zid_outbox;
create trigger zid_outbox_notify_trg after insert on public.zid_outbox
  for each statement execute function public.zid_outbox_notify();

-- جدولة: كل دقيقة مزامنة احتياطية مع زد، وكل يوم تنظيف
do $$ begin perform cron.unschedule('azm-zid-sync'); exception when others then null; end $$;
do $$ begin perform cron.unschedule('azm-housekeeping'); exception when others then null; end $$;
select cron.schedule('azm-zid-sync', '* * * * *', $$
  select public.call_zid_function('cron')
  where exists (select 1 from public.app_settings where key = 'zid_tokens' and value ? 'access_token')
$$);
select cron.schedule('azm-housekeeping', '15 0 * * *', $$ select public.housekeeping() $$);
